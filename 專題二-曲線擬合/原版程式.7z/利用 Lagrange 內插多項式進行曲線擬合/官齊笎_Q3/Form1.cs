﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

using System.Drawing.Imaging;   //支援多圖片格式

namespace 官齊笎_Q3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            list_point = new List<Point>();
            picture = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            graphic = Graphics.FromImage(picture);
            timer1.Interval = 10;
            timer1.Enabled = true;

            //取得或設定值，指出控制項是否能接受使用者拖放上來的資料。
            this.AllowDrop = true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            FullClose();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FullClose();
        }

        //徹底關閉程式
        public void FullClose()
        {
            System.Environment.Exit(0);
        }

        //說明文件
        private void explanationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string about = "版本:1.0\r\n\r\n";
            about += "先載入資料(拖曳也可)，再按執行內插，即可顯示圖片。\r\n";
            about += "可按 輸出圖片 按鈕輸出。\r\n\r\n";
            about += "輸入支援格式: 文字檔(*.txt)\r\n";
            about += "輸出支援格式: *.bmp 、 *.png 、 *.jpg";
            MessageBox.Show(about, "說明", MessageBoxButtons.OK);
        }

        //程式更新紀錄
        private void updateLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string about = "版本:1.0 (5/29)\r\n";
            about += "    江大衛:\r\n";
            about += "    官齊笎:\r\n";
            about += "        1. 尋找過去程式，可將散點用線做表達。\r\n";
            about += "        2. 前端設計\r\n";
            about += "    洪揮霖:\r\n";
            about += "        1. 尋找最小平方法的方法";
            MessageBox.Show(about, "更新日誌", MessageBoxButtons.OK);
        }

        List<Point> list_point;
        Bitmap picture;
        Graphics graphic;

        //滑鼠選取點座標
        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int x = (int)Math.Round(((double)e.X + pictureBox1.Left) / 5) * 5 / 20, y = (int)Math.Round(((double)e.Y + pictureBox1.Top) / 5) * 5 / 20;
            if (list_point.Where(v => v.X == x && v.Y == y).ToArray().Length != 0)
                return;
            list_point.Add(new Point(x, y));
            DrawEllipse(x, y);
        }

        //滑鼠移動
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            this.Text = e.X.ToString() + "," + e.Y.ToString() + " 利用Lagrange內插進行曲線擬合 ";
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            PictureBox pi = (PictureBox)sender;
            this.Text = (e.X + pi.Left).ToString() + "," + (e.Y + pi.Top).ToString() + " 利用Lagrange內插進行曲線擬合 ";
        }

        private void button_MouseMove(object sender, MouseEventArgs e)
        {
            Button bu = (Button)sender;
            this.Text = (e.X + bu.Left).ToString() + "," + (e.Y + bu.Top).ToString() + " 利用Lagrange內插進行曲線擬合 ";
        }

        private void checkBox1_MouseMove(object sender, MouseEventArgs e)
        {
            CheckBox ch = (CheckBox)sender;
            this.Text = (e.X + ch.Left).ToString() + "," + (e.Y + ch.Top).ToString() + " 利用Lagrange內插進行曲線擬合 ";
        }

        //用拖曳方式讀取檔案
        //在將物件拖入控制項的邊界時發生
        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;
        }

        //拖放操作完成時發生
        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] data = (e.Data.GetData("FileNameW") as string[]);
            //FilePath:檔案路徑、DefaultExt:附檔名
            string FilePath = data[0];
            Read_File(FilePath);
        }

        //用對話方塊讀取檔案
        private void Read_OpenFileDialog(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialogFunction = new OpenFileDialog();
            string windowFilter = "文字檔(*.txt)|*.txt";
            string windowTitle = "匯入資料";
            openFileDialogFunction.Filter = windowFilter;   //開窗搜尋副檔名
            openFileDialogFunction.Title = windowTitle;     //開窗標題
            if (openFileDialogFunction.ShowDialog() != DialogResult.OK)
                return;
            Read_File(openFileDialogFunction.FileName);
        }

        //根據檔案名稱抓數值資料，並傳到list_point
        //FilePath:檔案路徑
        public bool Read_File(string FilePath)
        {
            int[] input;
            DrawClear(null, null);
            input = (new StreamReader(FilePath)).ReadToEnd().Replace("\r\n", " ").Replace("\n", " ").Split(' ').Where(v => v != "").Select(v => int.Parse(v)).ToArray();
            for (int i = 0; i < input.Length; i += 2)
            {
                list_point.Add(new Point(input[i], input[i + 1]));
                DrawEllipse(list_point[i / 2].X, list_point[i / 2].Y);
            }
            return true;
        }

        //利用Lagrange內插進行曲線擬合
        private void LagrangeInterpolation(object sender, EventArgs e)
        {
            int d = 20;
            List<PointF> pf = new List<PointF>();
            for (float x = 0; x < 1600 / d; x += (float)0.1)
            {
                float f = 0;
                for (int j = 0; j < list_point.Count; j++)
                {
                    float s = 1;
                    for (int k = 0; k < list_point.Count; k++)
                        if (j != k && list_point[j].X - list_point[k].X != 0)
                            s *= (x - list_point[k].X) / (list_point[j].X - list_point[k].X);
                    f += list_point[j].Y * s;
                }
                pf.Add(new PointF(x * d, f * d));
            }
            DrawGrid(sender, e);
            for (int i = 0; i < pf.Count - 1; i++)
                try
                {
                    graphic.DrawLine(new Pen(Color.Red, 3), pf[i], pf[i + 1]);
                    SetImage();
                }
                catch { }
        }

        //程式啟動時清除畫面
        private void start_clear(object sender, EventArgs e)
        {
            DrawClear(sender, e);
            timer1.Enabled = false;
        }

        //清除畫面
        private void DrawClear(object sender, EventArgs e)
        {
            list_point = new List<Point>();
            DrawGrid(null, null);
        }

        //選擇是否畫格線
        private void DrawGrid(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                DrawLine(1);
            else
                DrawLine(0);
        }

        //畫格線
        public void DrawLine(int yn)
        {
            int d = 20;
            Pen pe = new Pen(Color.Black);
            graphic.Clear(this.BackColor);
            for (int i = 0; i < (yn == 1 ? pictureBox1.Width : 0); i += d)
                graphic.DrawLine(pe, i, 0, i, pictureBox1.Height);
            for (int i = 0; i < (yn == 1 ? pictureBox1.Height : 0); i += d)
                graphic.DrawLine(pe, 0, i, pictureBox1.Width, i);
            for (int i = 0; i < list_point.Count; i++)
                DrawEllipse(list_point[i].X, list_point[i].Y);
            SetImage();
        }

        //畫點
        public void DrawEllipse(int x, int y)
        {
            int d = 10;
            Pen pe = new Pen(Color.Blue, 2);
            graphic.DrawEllipse(pe, 20 * x - d / 2, 20 * y - d / 2, d, d);
            SetImage();
        }

        //顯示圖片
        public void SetImage()
        {
            pictureBox1.Image = picture;
        }

        //用對話方塊寫入圖片
        private void Write_OpenFileDialog(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialogFunction = new SaveFileDialog();
            string windowFilter = "*.bmp|.bmp" + "|*.png|.png" + "|*.jpg|.jpg";
            string windowTitle = "匯出資料";

            saveFileDialogFunction.Filter = windowFilter;   //開窗搜尋副檔名
            saveFileDialogFunction.Title = windowTitle;     //開窗標題
            if (saveFileDialogFunction.ShowDialog() == DialogResult.OK)
            {
                //FilePath:檔案路徑、DefaultExt:附檔名
                string FilePath = saveFileDialogFunction.FileName, DefaultExt = Path.GetExtension(FilePath);
                if (Write_Image(FilePath, DefaultExt))
                    MessageBox.Show("輸出完成", "通知");
                else
                    MessageBox.Show("輸出失敗", "警告");
            }
            else
                return;
        }

        //寫入圖片
        public bool Write_Image(string FilePath, string DefaultExt)
        {
            try
            {
                if (DefaultExt == ".bmp")
                    picture.Save(FilePath, ImageFormat.Bmp);
                else if (DefaultExt == ".png")
                    picture.Save(FilePath, ImageFormat.Png);
                else if (DefaultExt == ".jpg")
                    picture.Save(FilePath, ImageFormat.Jpeg);
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message, "警告");
                return false;
            }
            return true;
        }
    }
}

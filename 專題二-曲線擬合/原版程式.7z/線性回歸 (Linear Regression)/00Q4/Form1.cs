﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _00Q4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Graphics g;

        private void Form1_Load(object sender, EventArgs e)
        {
            g = pictureBox1.CreateGraphics();
            clear();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                button1_Click(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n;
            float[] x, y;
            clear();
            if (!int.TryParse(textBox1.Text, out n) || n < 2 || n > 10)
                return;
            x = new float[n];
            y = new float[n];
            textBox2.Text += n.ToString().PadLeft(2) + "\r\n";
            for (int i = 0; i < n; i++)
            {
                float x1, y1;
                string[] ipt = Microsoft.VisualBasic.Interaction.InputBox("請輸入第" + (i + 1).ToString() + "個點座標並用空格隔開:", "").Split(' ').Where(v => v != "").ToArray();
                if (ipt.Length != 2 || !float.TryParse(ipt[0], out x1) || !float.TryParse(ipt[1], out y1) || x1 < 1 || x1 > 8 || y1 < 1 || y1 > 8)
                    i--;
                else
                {
                    x[i] = x1;
                    y[i] = y1;
                    textBox2.Text += "請輸入每一個資料的x，y座標[x y]: [" + ipt[0].PadLeft(3) + " " + ipt[1].PadLeft(3) + "]\r\n";
                    g.DrawEllipse(new Pen(Color.Blue), 20 + 50 * (x1 - 1) - 5, 370 - (y1 - 1) * 50 - 5, 10, 10);
                }
            }
            Array.Sort(x, y);
            float s = 0, m, b;
            for (int i = 0; i < n; i++)
                s += x[i] * y[i];
            m = (s - x.Sum() * y.Average()) / (x.Select(v => v * v).Sum() - x.Sum() * x.Average());
            b = y.Average() - m * x.Average();
            textBox2.Text += "最小平方直線的回歸係數:\r\n" + "   斜率 (m)".PadRight(19) + "=" + m.ToString("f3").PadLeft(10) + "\r\n" + "   截距 (b)".PadRight(20) + "=" + b.ToString("f3").PadLeft(10) + "\r\n" + "   總資料點數".PadRight(13) + "=" + n.ToString().PadLeft(10);
            g.DrawLine(new Pen(Color.Red), 20, 370 - b * 50, 20 + 350, 370 - (b + m * 8 - 1) * 50);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }

        public void clear()
        {
            Pen p = new Pen(Color.Black);
            g.Clear(Color.White);
            g.DrawLine(p, 20, 20, 20, 370);
            g.DrawLine(p, 20, 370, 370, 370);
            g.DrawLine(p, 20, 20, 370, 20);
            g.DrawLine(p, 370, 20, 370, 370);
            p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            p.DashPattern = new float[] { 2, 2 };
            for (int i = 1; i < 7; i++)
            {
                g.DrawLine(p, 20, 20 + i * 50, 370, 20 + i * 50);
                g.DrawLine(p, 20 + i * 50, 20, 20 + i * 50, 370);
            }
            for (int i = 0; i < 8; i++)
            {
                g.DrawString((8 - i).ToString(), this.Font, Brushes.Black, 10, 15 + i * 50);
                g.DrawString((i + 1).ToString(), this.Font, Brushes.Black, 15 + i * 50, 375);
            }
            g.DrawString("線性回歸--最小平方逼近", this.Font, Brushes.Black, 130, 5);
            textBox2.Text = "線性回歸 (Linear Regression)\r\n利用最小平方方法讓一條直線來逼近一些點\r\n請輸入資料總點數:";
        }
    }
}
